package com.example.demo.controller;

public class User {
    
    public static String username="";
}
