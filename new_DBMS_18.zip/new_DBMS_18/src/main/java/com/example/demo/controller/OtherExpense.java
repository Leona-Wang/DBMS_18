package com.example.demo.controller;

public class OtherExpense {
    public String index="";
    public String date="";
    public String type="";
    public String cost="";

    public OtherExpense(String index,String date,String type,String cost){
        this.index=index;
        this.date=date;
        this.type=type;
        this.cost=cost;
    }
}
